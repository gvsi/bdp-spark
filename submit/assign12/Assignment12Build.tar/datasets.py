from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext

conf = SparkConf().setMaster("local").setAppName("WordCount")
sc = SparkContext(conf=conf)
sqlContext = SQLContext(sc)


df = sqlContext.read.format('com.databricks.spark.csv').options(header='true', inferSchema='true').load('/Users/gvsi/Developer/bdp/spark/data/assign12/dataSet12.csv')
sqlContext.registerDataFrameAsTable(df, 'user_sessions')

# By make/model, the min, max, and average price
df2 = sqlContext.sql("SELECT make, model, min(price), max(price), avg(price) FROM (SELECT DISTINCT make, model, price FROM user_sessions WHERE price != 0) GROUP BY make, model ORDER BY make, model")

# By year, the min, max, and average mileage
df3 = sqlContext.sql("SELECT year, min(mileage), max(mileage), avg(mileage) FROM (SELECT DISTINCT make, model, year, mileage FROM user_sessions WHERE mileage != 0) GROUP BY year ORDER BY year")

# By VIN, the total for each event type
splitRDD = df.rdd.map(lambda row: (row['userId'], row['event'].split(' ', 1)[0], row['event'].split(' ', 1)[1], row['timestamp'], row['vin'], row['condition'], row['year'], row['make'], row['model'], row['price'], row['mileage']))
eventDF_new = splitRDD.toDF(['userId', 'event_type', 'event_subtype', 'timestamp', 'vin', 'condition', 'year', 'make', 'model', 'price', 'mileage'])
sqlContext.registerDataFrameAsTable(eventDF_new, 'user_sessions2')
df4 = sqlContext.sql("SELECT vin, event_type, count(event_subtype) FROM user_sessions2 GROUP BY vin, event_type ORDER BY vin, event_type ")


# Write all three results to file
(df2.repartition(1)
 .write
 .format("csv")
 .save("/Users/gvsi/Developer/bdp/spark/output/Assign12Run1"))

(df3.repartition(1)
 .write
 .format("csv")
 .save("/Users/gvsi/Developer/bdp/spark/output/Assign12Run2"))

(df4.repartition(1)
 .write
 .format("csv")
 .save("/Users/gvsi/Developer/bdp/spark/output/Assign12Run3"))